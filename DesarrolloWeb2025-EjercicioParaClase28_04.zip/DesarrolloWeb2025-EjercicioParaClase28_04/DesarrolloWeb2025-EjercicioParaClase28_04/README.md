alt + z: Para ajustar línea al tamaño de la ventana

ctrl + k + c: Para comentar varias líneas de código HTML

Shift+Alt + ↓ / ↑ Copiar line arriba/abajo 

Shift+Alt+F Format document 

Ctrl+K Ctrl+F Format selection

Alt+ ↑ / ↓ Move line up/down
